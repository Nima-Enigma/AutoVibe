package com.autovibe.network;

import android.content.Context;
import android.util.Log;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.*;

public class MQTTHelper {
    private final Context context;
    private final String brokerUrl;
    private final String port;
    private final String clientId;
    private final String username;
    private final String password;
    private MqttAndroidClient mqttClient;
    private ConnectionListener connectionListener;

    public interface ConnectionListener {
        void onConnectionSuccess();
        void onConnectionFailure(Throwable exception);
    }

    public MQTTHelper(Context context, String brokerUrl, String port, String clientId,
                      String username, String password) {
        this.context = context;
        this.brokerUrl = brokerUrl;
        this.port = port;
        this.clientId = clientId;
        this.username = username;
        this.password = password;
    }

    public void setConnectionListener(ConnectionListener listener) {
        this.connectionListener = listener;
    }

    public void connect() {
        String serverUri = brokerUrl + ":" + port;
        mqttClient = new MqttAndroidClient(context, serverUri, clientId);

        mqttClient.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                if (connectionListener != null) {
                    connectionListener.onConnectionFailure(
                            cause != null ? cause : new Exception("Connection lost"));
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {}

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {}
        });

        MqttConnectOptions options = new MqttConnectOptions();
        options.setCleanSession(true);

        if (username != null && !username.isEmpty()) {
            options.setUserName(username);
        }

        if (password != null && !password.isEmpty()) {
            options.setPassword(password.toCharArray());
        }

        try {
            mqttClient.connect(options, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    if (connectionListener != null) {
                        connectionListener.onConnectionSuccess();
                    }
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    if (connectionListener != null) {
                        connectionListener.onConnectionFailure(
                                exception != null ? exception : new Exception("Unknown connection error"));
                    }
                }
            });
        } catch (MqttException e) {
            if (connectionListener != null) {
                connectionListener.onConnectionFailure(e);
            }
        }
    }

    public void disconnect() {
        try {
            if (mqttClient != null && mqttClient.isConnected()) {
                mqttClient.disconnect();
            }
        } catch (MqttException e) {
            Log.e("MQTT", "Disconnect error", e);
        }
    }
}