package com.autovibe.screens.mqttConnect;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.autovibe.network.MQTTHelper;

public class MQTTConnectViewModel extends ViewModel {
    private MutableLiveData<Boolean> _connectionStatus = new MutableLiveData<>();
    private MutableLiveData<String> _errorMessage = new MutableLiveData<>();

    public LiveData<Boolean> connectionStatus() { return _connectionStatus; }
    public LiveData<String> errorMessage() { return _errorMessage; }

    private MQTTHelper mqttHelper;

    public void connect(Context context, String brokerUrl, String port,
                        String clientId, String username, String password) {
        if (brokerUrl.isEmpty() || port.isEmpty()) {
            _errorMessage.postValue("Please fill all required fields");
            return;
        }

        mqttHelper = new MQTTHelper(context, brokerUrl, port, clientId, username, password);
        mqttHelper.setConnectionListener(new MQTTHelper.ConnectionListener() {
            @Override
            public void onConnectionSuccess() {
                _connectionStatus.postValue(true);
            }

            @Override
            public void onConnectionFailure(Throwable exception) {
                _errorMessage.postValue("Connection failed: " + exception.getMessage());
                _connectionStatus.postValue(false);
            }
        });
        mqttHelper.connect();
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (mqttHelper != null) {
            mqttHelper.disconnect();
        }
    }
}