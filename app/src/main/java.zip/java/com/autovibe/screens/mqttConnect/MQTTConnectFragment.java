package com.autovibe.screens.mqttConnect;// MQTTConnectFragment.java

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.autovibe.MainActivity;
import com.autovibe.R;

public class MQTTConnectFragment extends Fragment {
    private MQTTConnectViewModel viewModel;
    private EditText editBrokerUrl, editPort, editClientId, editUsername, editPassword;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.mqtt_connection, container, false);
        initializeViews(view);
        setupViewModel();
        return view;
    }

    private void initializeViews(View view) {
        editBrokerUrl = view.findViewById(R.id.editTextBrokerUrl);
        editPort = view.findViewById(R.id.editTextPort);
        editClientId = view.findViewById(R.id.editTextClientId);
        editUsername = view.findViewById(R.id.editTextUsername);
        editPassword = view.findViewById(R.id.editTextPassword);

        Button connectButton = view.findViewById(R.id.buttonConnect);
        connectButton.setOnClickListener(v -> attemptConnection());
    }

    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(MQTTConnectViewModel.class);

        viewModel.connectionStatus().observe(getViewLifecycleOwner(), success -> {
            if (success) {
                Toast.makeText(requireContext(), "Connected successfully!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(requireActivity(), MainActivity.class));
                requireActivity().finish();
            }
        });

        viewModel.errorMessage().observe(getViewLifecycleOwner(), message -> {
            if (message != null && !message.isEmpty()) {
                Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void attemptConnection() {
        String brokerUrl = editBrokerUrl.getText().toString().trim();
        String port = editPort.getText().toString().trim();
        String clientId = editClientId.getText().toString().trim();
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        // Set default client ID if empty
        if (clientId.isEmpty()) {
            clientId = "android-client-" + System.currentTimeMillis();
        }

        viewModel.connect(requireContext().getApplicationContext(),
                brokerUrl, port, clientId, username, password);
    }
}